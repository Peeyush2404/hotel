package com.example.hotel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.hotel.adapter.RecentsAdapter;
import com.example.hotel.adapter.TopPlacesAdapter;
import com.example.hotel.model.RecentsData;
import com.example.hotel.model.TopPlacesData;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recentRecycler,topPlacesRecycler;
    RecentsAdapter recentsAdapter;
    TopPlacesAdapter topPlacesAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        List<RecentsData> recentsDataList=new ArrayList<>();
        recentsDataList.add(new RecentsData("JW MARRIOT HOTEL","Chandigarh","From Rs 8000",R.drawable.h1));
        recentsDataList.add(new RecentsData("JW MARRIOT HOTEL","Chandigarh","From Rs 8000",R.drawable.h2));
        recentsDataList.add(new RecentsData("JW MARRIOT HOTEL","Chandigarh","From Rs 8000",R.drawable.h3));
        recentsDataList.add(new RecentsData("JW MARRIOT HOTEL","Chandigarh","From Rs 8000",R.drawable.h4));
        recentsDataList.add(new RecentsData("JW MARRIOT HOTEL","Chandigarh","From Rs 8000",R.drawable.h6));

        setRecentRecycler(recentsDataList);
        List<TopPlacesData> topPlacesDataList=new ArrayList<>();
        topPlacesDataList.add(new TopPlacesData("JW MARRIOT HOTEL","Chandigarh"," From Rs 8000 ",R.drawable.h7));
        topPlacesDataList.add(new TopPlacesData("JW MARRIOT HOTEL","Chandigarh"," From Rs 8000 ",R.drawable.h8));
        topPlacesDataList.add(new TopPlacesData("JW MARRIOT HOTEL","Chandigarh"," From Rs 8000 ",R.drawable.h9));
        topPlacesDataList.add(new TopPlacesData("JW MARRIOT HOTEL","Chandigarh"," From Rs 8000 ",R.drawable.h10));
        topPlacesDataList.add(new TopPlacesData("JW MARRIOT HOTEL","Chandigarh"," From Rs 8000 ",R.drawable.h10));
        topPlacesDataList.add(new TopPlacesData("JW MARRIOT HOTEL","Chandigarh"," From Rs 8000 ",R.drawable.h10));

        setTopPlacesRecycler(topPlacesDataList);

    }
    private void setRecentRecycler(List<RecentsData> recentsDataList)
    {
        recentRecycler=findViewById(R.id.recent_recycler);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(this,RecyclerView.HORIZONTAL,false);
        recentRecycler.setLayoutManager(layoutManager);
        recentsAdapter=new RecentsAdapter(this,recentsDataList);
        recentRecycler.setAdapter(recentsAdapter);
    }
    private void setTopPlacesRecycler(List<TopPlacesData> topPlacesDataList)
    {
        topPlacesRecycler=findViewById(R.id.top_places_recycler);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(this,RecyclerView.VERTICAL,false);
       topPlacesRecycler.setLayoutManager(layoutManager);
        topPlacesAdapter=new TopPlacesAdapter(this,topPlacesDataList);
        topPlacesRecycler.setAdapter(topPlacesAdapter);
    }
}